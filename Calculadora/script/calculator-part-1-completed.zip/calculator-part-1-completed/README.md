# Calculator Part 1 completed

A Pen created on CodePen.io. Original URL: [https://codepen.io/zellwk/pen/MVbVZV](https://codepen.io/zellwk/pen/MVbVZV).

This is the source code  file for a blog post "How to build a calculator". You can follow the lesson at https://zellwk.com/blog/calculator-part-1
